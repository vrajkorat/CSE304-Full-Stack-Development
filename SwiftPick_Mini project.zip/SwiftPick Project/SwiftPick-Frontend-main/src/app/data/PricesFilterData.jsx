export const Prices = [
  {
    _id: 0,
    name: "$0 to 99",
    value: "0,99",
  },
  {
    _id: 1,
    name: "$199 to 399",
    value: "199,399",
  },
  {
    _id: 2,
    name: "$399 to 499",
    value: "399,499",
  },
  {
    _id: 4,
    name: "$599 to 699",
    value: "599,699",
  },
  {
    _id: 5,
    name: "$799 to 899",
    value: "799,899",
  },
  {
    _id: 6,
    name: "$1000 or more",
    value: "1000,100000",
  },
];
